
let selected="";

function chooseFrame(frame){
selected=frame;
localStorage.frame=frame;
document.getElementById("preview").src="assets/frames/"+frame;
}

function goCamera(){
location.href="camera.html";
}
