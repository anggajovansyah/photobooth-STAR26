
const video=document.getElementById("video");
const overlay=document.getElementById("overlay");

overlay.src="assets/frames/"+localStorage.frame;

navigator.mediaDevices.getUserMedia({video:true})
.then(stream=>video.srcObject=stream);

function capture(){

let c=3;

let timer=setInterval(()=>{
document.getElementById("count").innerHTML=c;
c--;

if(c<0){
clearInterval(timer);

let canvas=document.getElementById("canvas");
canvas.width=video.videoWidth;
canvas.height=video.videoHeight;

let ctx=canvas.getContext("2d");
ctx.drawImage(video,0,0);

let img=new Image();
img.src=overlay.src;

img.onload=()=>{
ctx.drawImage(img,0,0,canvas.width,canvas.height);
localStorage.photo=canvas.toDataURL();
location.href="result.html";
}

}},1000)

}
