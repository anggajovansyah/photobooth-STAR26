
document.getElementById("result").src=localStorage.photo;

function download(){
let a=document.createElement("a");
a.href=localStorage.photo;
a.download="HMIF-photo.jpg";
a.click();
}
